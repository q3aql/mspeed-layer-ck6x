# Enter script code
keyboard.send_keys("<home>")