# Enter script code
keyboard.send_keys("<code121>")