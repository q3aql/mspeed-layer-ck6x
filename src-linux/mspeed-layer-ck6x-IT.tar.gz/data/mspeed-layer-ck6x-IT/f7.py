# Enter script code
keyboard.send_keys("<f7>")