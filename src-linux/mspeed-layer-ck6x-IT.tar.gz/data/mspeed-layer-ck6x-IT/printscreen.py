# Enter script code
keyboard.send_keys("<print_screen>")